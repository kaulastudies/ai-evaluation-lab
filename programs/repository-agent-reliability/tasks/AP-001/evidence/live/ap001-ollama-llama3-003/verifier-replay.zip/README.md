# RARB AP-001 Replay Bundle

Task: AP-001
Run label: ap001-ollama-llama3-003
Recorded verdict: VERIFIED_PASS
Record hash: ae57414f3a7fd0e13b6574f68c35eaf85d6ccf1ba05f541b13d32f95f78aa4fe

This is a post-run audit artifact. It contains the exact candidate, public tests,
qualified verifier source, qualification evidence, task contract, model-context
manifest, and evaluation record needed to reproduce the recorded verdict without
calling the model again.

Replay:

    python replay.py

A successful replay means that artifact hashes, public-test outcome, verifier gates,
final verdict, false-green classification, and evaluation-record hash all match the
recorded run.

The verifier is included for post-run auditability. Do not expose this replay bundle
to an agent before evaluating a fresh attempt on the same benchmark task.

Verifier re-qualification controls/reference solutions are intentionally not included.
To re-qualify the verifier itself, use the full AI Evaluation Lab repository.
